-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: biz_horizon
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `catalog`
--

DROP TABLE IF EXISTS `catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `catalog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog`
--

LOCK TABLES `catalog` WRITE;
/*!40000 ALTER TABLE `catalog` DISABLE KEYS */;
INSERT INTO `catalog` VALUES (3,'Laptop','High-performance laptop with 16GB RAM and 512GB SSD',1200.00),(4,'Smartphone','Latest model smartphone with 5G connectivity and 128GB storage',800.00),(5,'Headphones','Noise-cancelling over-ear headphones with 20 hours battery life',150.00),(6,'Smartwatch','Water-resistant smartwatch with heart rate monitor and GPS',250.00),(7,'Tablet','10-inch tablet with 64GB storage and stylus support',300.00),(8,'Wireless Speaker','Portable wireless speaker with Bluetooth connectivity',100.00),(9,'Camera','Digital camera with 24MP sensor and 4K video recording',500.00),(10,'Gaming Console','Next-gen gaming console with 1TB storage',400.00),(11,'Monitor','27-inch 4K monitor with HDR support',350.00),(12,'Keyboard','Mechanical keyboard with customizable RGB backlight',75.00),(13,'Laptop','High-performance laptop with 16GB RAM and 512GB SSD',1200.00),(14,'Smartphone','Latest model smartphone with 5G connectivity and 128GB storage',800.00),(15,'Headphones','Noise-cancelling over-ear headphones with 20 hours battery life',150.00),(16,'Smartwatch','Water-resistant smartwatch with heart rate monitor and GPS',250.00),(17,'Tablet','10-inch tablet with 64GB storage and stylus support',300.00),(18,'Wireless Speaker','Portable wireless speaker with Bluetooth connectivity',100.00),(19,'Camera','Digital camera with 24MP sensor and 4K video recording',500.00),(20,'Gaming Console','Next-gen gaming console with 1TB storage',400.00),(21,'Monitor','27-inch 4K monitor with HDR support',350.00),(22,'Keyboard','Mechanical keyboard with customizable RGB backlight',75.00),(23,'Jewelry1','Unique Stylish gifts',100.00),(24,'Jewelry1','Unique Stylish gifts',100.00);
/*!40000 ALTER TABLE `catalog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-01 10:20:50
