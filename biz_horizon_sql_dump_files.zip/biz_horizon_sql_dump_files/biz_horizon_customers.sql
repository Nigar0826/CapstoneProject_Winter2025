-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: biz_horizon
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Liam Wilson','liam.wilson@example.com','123-555-7890'),(2,'Emma Larsen','emma.larsen@example.com','234-555-8901'),(3,'Jack David Dawson','jack.d2@email.com','123-456-7890'),(4,'Jackie Dawson','jackie.d@email.com','123-456-7890'),(5,'Noah White','noah.white@example.com','567-555-1234'),(6,'Ava Clark','ava.clark@example.com','678-555-2345'),(7,'William Lopez','william.lopez@example.com','789-555-3456'),(8,'Isabella Harris','isabella.harris@example.com','890-555-4567'),(9,'John Smith','john.smith@example.com','123-456-7890'),(10,'Jane Doe','jane.doe@example.com','234-567-8901'),(11,'Michael Johnson','michael.johnson@example.com','345-678-9012'),(12,'Emily Davis','emily.davis@example.com','456-789-0123'),(13,'David Wilson','david.wilson@example.com','567-890-1234'),(14,'Sarah Brown','sarah.brown@example.com','678-901-2345'),(15,'James Taylor','james.taylor@example.com','789-012-3456'),(16,'Olivia Martin','olivia.martin@example.com','890-123-4567'),(17,'Daniel Garcia','daniel.garcia@example.com','901-234-5678'),(18,'Sophia Martinez','sophia.martinez@example.com','012-345-6789'),(19,'Louie Vitton','l.vitton@gmail.com','1234567989'),(20,'Julie Frank','j.frank@example.com','123-456-7890'),(21,'Fatima','fatima.a@gmail.com','1523456789'),(24,'Juliet Frank','j.frankie@example.com','123-456-7890'),(25,'Thilak','thilak@email.com','123-456-7890'),(26,'Rose','rose@hotmail.com','12345');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-01 10:20:50
