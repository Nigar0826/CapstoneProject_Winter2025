-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: biz_horizon
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` int(11) NOT NULL,
  `currency` varchar(10) NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,10000,'cad','pending','2025-01-31 18:46:11'),(2,10000,'cad','pending','2025-01-31 18:46:44'),(3,10000,'cad','pending','2025-01-31 18:46:53'),(4,10000,'cad','pending','2025-01-31 18:47:01'),(5,10000,'cad','pending','2025-01-31 18:47:12'),(6,1000,'cad','pending','2025-01-31 19:07:24'),(7,1000,'cad','pending','2025-01-31 19:07:42'),(8,1000,'cad','pending','2025-01-31 19:19:20'),(9,1000,'cad','pending','2025-01-31 20:09:41'),(10,10000,'cad','pending','2025-01-31 22:32:40'),(11,10000,'cad','pending','2025-01-31 23:48:46'),(12,100000,'cad','pending','2025-02-11 07:58:04'),(13,100000,'cad','pending','2025-02-11 07:58:11'),(14,100000,'cad','pending','2025-02-11 07:58:19'),(15,100000,'cad','pending','2025-02-11 07:58:29'),(16,10000,'cad','pending','2025-02-11 12:15:54'),(17,10000,'cad','pending','2025-02-11 12:16:00'),(18,10000,'cad','pending','2025-02-11 12:16:07'),(19,10000,'cad','pending','2025-02-11 12:16:15'),(20,10000,'cad','pending','2025-02-11 12:16:21'),(21,1000,'cad','pending','2025-02-11 12:51:43'),(22,10000,'cad','pending','2025-02-11 13:26:41'),(23,10000,'cad','pending','2025-02-11 13:43:01'),(24,10000,'cad','pending','2025-02-11 13:43:08'),(25,10000,'cad','pending','2025-02-11 13:43:16'),(26,10000,'cad','pending','2025-02-11 13:43:21'),(27,10000,'cad','pending','2025-02-11 13:43:35'),(28,10000,'cad','pending','2025-02-11 13:43:42'),(29,10000,'cad','pending','2025-02-11 13:43:49'),(30,10000,'cad','pending','2025-02-11 13:43:53'),(31,1000,'cad','pending','2025-02-11 13:45:31'),(32,1000,'cad','pending','2025-02-16 22:34:08');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-01 10:20:50
